<?php

return [
    'name' => 'Quotes'
];
