<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Customers\\Providers\\CustomersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Customers\\Providers\\CustomersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);