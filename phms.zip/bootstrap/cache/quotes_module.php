<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Quotes\\Providers\\QuotesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Quotes\\Providers\\QuotesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);