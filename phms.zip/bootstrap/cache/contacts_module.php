<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Contacts\\Providers\\ContactsServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Contacts\\Providers\\ContactsServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);