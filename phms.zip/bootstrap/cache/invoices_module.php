<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Invoices\\Providers\\InvoicesServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Invoices\\Providers\\InvoicesServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);